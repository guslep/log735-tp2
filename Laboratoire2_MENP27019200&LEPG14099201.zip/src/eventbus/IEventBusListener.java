package eventbus;

public interface IEventBusListener {

}
