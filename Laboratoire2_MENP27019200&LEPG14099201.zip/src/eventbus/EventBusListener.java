package eventbus;

public class EventBusListener implements IEventBusListener {

}
